import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

repo = Path('/Users/marte/Code/nam_holdsworth/NeuralAmpModelerPlugin')
out = Path('/private/tmp/nam-eq-git-integration')
env = dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
cxx = subprocess.check_output(['xcrun', '--find', 'clang++'], env=env, text=True).strip()
sdk = subprocess.check_output(['xcrun', '--show-sdk-path'], env=env, text=True).strip()
common = [cxx, '-isysroot', sdk, '-isystem', sdk + '/usr/include/c++/v1', '-std=c++20', '-pthread']
sources = sorted(str(p.relative_to(repo)) for pattern in ('dsp/*.cpp', 'integration/*.cpp', 'tests/*.cpp')
                 for p in (repo / 'HoldsworthEngine').glob(pattern))
report = {'date': '2026-10-21', 'scope': 'Final pre-commit revalidation; accepted DSP unchanged', 'checks': []}

def run(name, command, extra_env=None):
    start = time.monotonic()
    with (out / 'logs' / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=repo, env=dict(env, **(extra_env or {})), stdout=log, stderr=subprocess.STDOUT)
    text = (out / 'logs' / (name + '.log')).read_text()
    report['checks'].append({'name': name, 'command': command, 'exit_code': result.returncode,
                             'elapsed_seconds': round(time.monotonic() - start, 3),
                             'log_sha256': hashlib.sha256(text.encode()).hexdigest(),
                             'summary': text.splitlines()[-1] if text.splitlines() else 'clean'})
    (out / 'final-validation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(name, result.returncode, report['checks'][-1]['summary'], flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

for mode, flags in [('debug', ['-O0', '-g']), ('release', ['-O3', '-DNDEBUG']),
                    ('asan', ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer']),
                    ('tsan', ['-O1', '-g', '-fsanitize=thread'])]:
    binary = str(out / ('tests-' + mode))
    run('compile-' + mode, common + flags + sources + ['-o', binary])
    run('tests-' + mode, [binary] + (['concurr'] if mode == 'tsan' else []),
        {'ASAN_OPTIONS': 'detect_leaks=0:halt_on_error=1', 'UBSAN_OPTIONS': 'halt_on_error=1'})

eq_sources = ['HoldsworthEngine/dsp/PostAmpEQProcessor.cpp'] + [
    'HoldsworthEngine/tests/PostAmpEQ' + tail + 'Tests.cpp' for tail in ('', 'Control', 'Transition')]
run('strict-warnings', common + ['-Wall', '-Wextra', '-Wpedantic', '-Wconversion', '-Wsign-conversion', '-Werror', '-fsyntax-only'] + eq_sources)
for source in eq_sources:
    run('analyzer-' + Path(source).stem, common + ['--analyze', '-Xanalyzer', '-analyzer-output=text', source, '-o', '/dev/null'])
run('source-audit', ['python3', 'HoldsworthEngine/references/post-amp-eq-v1/source-audit.py'])
run('rt-source-audit', ['python3', 'HoldsworthEngine/references/post-amp-eq-v1/rt-source-audit.py'])
run('project-lint', ['plutil', '-lint', 'NeuralAmpModeler/projects/NeuralAmpModeler-macOS.xcodeproj/project.pbxproj'])
run('diff-check', ['git', 'diff', '--check'])
