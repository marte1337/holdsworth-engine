import os,pathlib,subprocess,shlex,json,hashlib
root=pathlib.Path('/private/tmp/nam-eq-timing-investigation/baseline')
repo=pathlib.Path('/Users/marte/Code/nam_holdsworth/NeuralAmpModelerPlugin')
env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
cxx=subprocess.check_output(['xcrun','--find','clang++'],env=env,text=True).strip()
sdk=subprocess.check_output(['xcrun','--show-sdk-path'],env=env,text=True).strip()
frameworks=[]
for name in ('Cocoa','Carbon','CoreFoundation','CoreData','Foundation','CoreServices','QuartzCore','AppKit','CoreMIDI','CoreAudio','AudioToolbox','AudioUnit','Accelerate','Metal','MetalKit'): frameworks+=['-framework',name]
manifest={}
for label,build,source in [('baseline',root,root/'source'),('current',pathlib.Path('/private/tmp/nam-post-amp-eq-v1'),repo)]:
 target=build/'build-APP/obj/NeuralAmpModeler-macOS.build/Release/APP.build/Objects-normal/arm64'
 response=next(p for p in target.glob('*common-args.resp') if '-std=c++20' in p.read_text())
 options=[p for p in shlex.split(response.read_text()) if p not in ('-fvisibility=hidden','-fvisibility-inlines-hidden')]
 objects=[p for p in (target/'NeuralAmpModeler.LinkFileList').read_text().splitlines() if pathlib.Path(p).name!='IPlugAPP_main.o']
 header=source/'HoldsworthEngine/references/tuner-v1/host-acceptance.h'
 command=[cxx,'-arch','arm64','-isysroot',sdk,'-mmacosx-version-min=12.0','-pthread']+options+['-O3','-DHOST_ACCEPTANCE="'+str(header)+'"','-Wl,-export_dynamic','-Wl,-dead_strip']
 if label=='current': command+=['-DTIMING_CURRENT_EQ']
 command+=[str(root/'app-timing.mm')]+objects+frameworks+['-o',str(root/('app-'+label))]
 (root/('command-'+label+'.json')).write_text(json.dumps(command,indent=2)+'\n')
 with (root/('compile-'+label+'.log')).open('w') as log:
  r=subprocess.run(command,cwd=source/'NeuralAmpModeler/projects',env=env,stdout=log,stderr=subprocess.STDOUT)
 print(label,r.returncode,flush=True)
 if r.returncode: raise SystemExit(r.returncode)
 manifest[label]={'runner_sha256':hashlib.sha256((root/('app-'+label)).read_bytes()).hexdigest(),'source':str(source),'objects':{str(p):hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in objects},'compiler':cxx,'compile_options_response':str(response)}
(root/'runner-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
