// Temporary investigation harness; product DSP is linked unchanged.
#include HOST_ACCEPTANCE
#include "IPlugSWELL.h"
#include <ctime>
#include <string>

thread_local bool inAudio = false;
std::atomic<unsigned> rtViolations{0};
HWND gHWND = nullptr;
INT_PTR SWELLAppMain(int, INT_PTR, INT_PTR) { return 0; }

constexpr int blockFrames = 4096;
constexpr double sampleRate = 176400.;

struct Instance {
  std::unique_ptr<iplug::IPlugAPP> wrapper{iplug::MakePlug(iplug::InstanceInfo{nullptr})};
  Instance() {
    assert(wrapper && wrapper->GetLatency() == 32);
    iplug::IPlugLatencyTestAccess::prepare(*wrapper, sampleRate, blockFrames);
    wrapper->OnReset();
    dryControls(*wrapper);
  }
  ~Instance() { wrapper->OnUIClose(); }
  void render(double* input,double* left,double* right) {
    double* inputs[]{input}; double* outputs[]{left,right};
    wrapper->AppProcess(inputs, outputs, blockFrames);
  }
};

#ifdef TIMING_CURRENT_EQ
#include "/Users/marte/Code/nam_holdsworth/NeuralAmpModelerPlugin/HoldsworthEngine/dsp/PostAmpEQControls.h"
void updateEQ(iplug::IPlugAPIBase& plugin, const std::string& mode, const unsigned callback) {
  using namespace holdsworth::dsp;
  PostAmpEQControls c;
  c.enabled = mode != "bypass";
  if (mode != "bypass" && mode != "neutral") {
    c.highPassEnabled = true; c.highPassHz = 80.;
    c.lowPassEnabled = true; c.lowPassHz = 8000.;
    c.bands = {{{250., 6., .7}, {1000., -9., 1.4}, {3500., 9., 2.}}};
  }
  if (mode == "sweep" || mode == "sweep_enable") {
    // Deterministic legal-range control path, outside callback timing.
    for (unsigned b = 0; b != 3; ++b) {
      const double t = static_cast<double>((callback * 37u + b * 101u) % 997u) / 996.;
      const double u = static_cast<double>((callback * 79u + b * 163u) % 991u) / 990.;
      c.bands[b] = {80. * std::pow(100., t), -12. + 24. * u, .35 * std::pow(4. / .35, 1. - t)};
    }
    const double v = static_cast<double>((callback * 47u) % 983u) / 982.;
    c.highPassHz = 20. * std::pow(10., v); c.lowPassHz = 3000. * std::pow(16000. / 3000., 1. - v);
    c.trimDb = -24. + 30. * v;
    if (mode == "sweep_enable") {
      c.enabled = (callback % 3u) != 0;
      c.highPassEnabled = (callback % 2u) == 0; c.lowPassEnabled = (callback % 5u) != 0;
    }
  }
  for (std::size_t i = 0; i != kPostAmpEQParameterCount; ++i) {
    const auto id = static_cast<PostAmpEQParameter>(i);
    developmentControl(plugin, kMsgTagPostAmpEQ, kCtrlTagEQEnable + static_cast<int>(i),
      postAmpEQParameterToNormalized(id, postAmpEQParameterValue(c,id)));
  }
}
#else
void updateEQ(iplug::IPlugAPIBase&, const std::string& mode, const unsigned) { assert(mode == "baseline"); }
#endif

static double cpuNowUs() {
  timespec t{}; assert(clock_gettime(CLOCK_THREAD_CPUTIME_ID, &t) == 0);
  return static_cast<double>(t.tv_sec) * 1.e6 + static_cast<double>(t.tv_nsec) * 1.e-3;
}

int main(int argc,char** argv) {
  assert(argc >= 2);
  const std::string mode = argv[1];
  const unsigned measured = argc > 2 ? static_cast<unsigned>(std::stoul(argv[2])) : 2048u;
  const unsigned warm = argc > 3 ? static_cast<unsigned>(std::stoul(argv[3])) : 256u;
  assert(measured > 0);
  auditSelfTest();
  Instance host;
  std::array<double,blockFrames> input{},left{},right{};
  signal(input,0,sampleRate,2);
  std::vector<std::array<double,2>> times(measured);
  const bool changes = mode == "sweep" || mode == "sweep_enable";
  updateEQ(*host.wrapper,mode,0);
  for(unsigned i=0;i!=warm;++i) {
    if(changes) updateEQ(*host.wrapper,mode,i);
    host.render(input.data(),left.data(),right.data());
  }
  const unsigned warmViolations = rtViolations.exchange(0);
  using Clock = std::chrono::steady_clock;
  for(unsigned i=0;i!=measured;++i) {
    if(changes) updateEQ(*host.wrapper,mode,i+warm);
    const auto wallStart = Clock::now();
    const double cpuStart = cpuNowUs();
    inAudio = true;
    host.render(input.data(),left.data(),right.data());
    inAudio = false;
    const double cpuEnd = cpuNowUs();
    const auto wallEnd = Clock::now();
    times[i] = {std::chrono::duration<double,std::micro>(wallEnd-wallStart).count(),cpuEnd-cpuStart};
  }
  double checksum=0.;
  for(unsigned i=0;i!=blockFrames;++i) { assert(std::isfinite(left[i]) && std::isfinite(right[i])); checksum+=left[i]+right[i]; }
  assert(host.wrapper->GetLatency() == 32);
  const unsigned violations=rtViolations.load();
  std::fprintf(stderr,"mode=%s rate=%.0f frames=%d warm=%u measured=%u warm_rt_calls=%u measured_rt_calls=%u latency=32 checksum=%.17g\n",mode.c_str(),sampleRate,blockFrames,warm,measured,warmViolations,violations,checksum);
  std::puts("scope,mode,rate_hz,frames,index,wall_us,thread_cpu_us,wall_minus_thread_cpu_us,deadline_us,wall_overrun,cpu_overrun");
  const double deadline=1.e6*blockFrames/sampleRate;
  for(unsigned i=0;i!=measured;++i) {
    const auto [wall,cpu]=times[i];
    std::printf("APP_Release_objects,%s,%.0f,%d,%u,%.9f,%.9f,%.9f,%.9f,%d,%d\n",mode.c_str(),sampleRate,blockFrames,i,wall,cpu,wall-cpu,deadline,wall>deadline,cpu>deadline);
  }
  return violations ? 2 : 0;
}
