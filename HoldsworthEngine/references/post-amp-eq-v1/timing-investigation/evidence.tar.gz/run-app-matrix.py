import os
from pathlib import Path
import json
import subprocess
import time

root=Path('/private/tmp/nam-eq-timing-investigation')
out=root/'app'; out.mkdir(exist_ok=True)
env=dict(os.environ,DYLD_INSERT_LIBRARIES='/private/tmp/nam-post-amp-eq-v1/host-tests/rt-audit.dylib')
modes=['baseline','bypass','neutral','active','sweep','sweep_enable']
record=[]
for trial in range(12):
    for order in range(len(modes)):
        mode=modes[(order+trial)%len(modes)]
        executable=root/'baseline'/('app-baseline' if mode=='baseline' else 'app-current')
        path=out/f'run-{trial:02d}-{order}-{mode}'
        start=time.monotonic()
        with path.with_suffix('.csv').open('w') as stream, path.with_suffix('.stderr').open('w') as errors:
            result=subprocess.run([str(executable),mode,'2048','256'],env=env,stdout=stream,stderr=errors,timeout=120)
        record.append({'trial':trial,'order':order,'mode':mode,'exit_code':result.returncode,
                       'raw_csv':str(path.with_suffix('.csv')),'stderr':str(path.with_suffix('.stderr')),
                       'process_elapsed_seconds':time.monotonic()-start})
        (out/'runs.json').write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps(record[-1]),flush=True)
        if result.returncode: raise SystemExit(result.returncode)
