from pathlib import Path
import csv
import hashlib
import json
import platform

root=Path('/private/tmp/nam-eq-timing-investigation')
isolated=json.loads((root/'isolated/aggregate.json').read_text())
app=json.loads((root/'app/aggregate.json').read_text())
overruns=json.loads((root/'app/overruns.json').read_text())
for name,data in isolated.items():
    data['cpu_available']=not name.startswith('original-wall')
    if not data['cpu_available']:
        data['cpu']=None
        data['cpu_overruns']=None
        data['wall_max_paired_sample']['cpu_us']=None
        data['wall_max_paired_sample']['wall_minus_cpu_us']=None
verification=json.loads((root/'final-source-verification.json').read_text())
cal=json.loads((root/'isolated/calibration-summary.json').read_text())
files=[root/'isolated/raw.csv',root/'isolated/summary.csv',root/'isolated/calibration.csv']
files+=sorted((root/'app').glob('run-*.csv'))
result={
 'diagnosis':'No reproducible EQ-specific CPU execution-time failure found; measured wall overruns are dominated by time not charged to the benchmark thread.',
 'original_sample':{'scope':'isolated PostAmpEQProcessor::processBlock, with target adoption/coefficient work; no NAM/IR/delay/framework',
    'mode':'continuous-sweep','rate_hz':176400,'frames':4096,'deadline_us':4096/176400*1e6,
    'wall_max_us':27097.583,'thread_cpu_us':None,'raw_sample_trace_available':False,
    'limits':'Original retained sorted aggregate only: no paired CPU value, callback index or scheduler trace. One original CSV row had a maximum above deadline; exact original per-callback overrun count is not recoverable.'},
 'method':{'warm_trials_per_mode':12,'measured_callbacks_per_trial':2048,'warm_callbacks_per_trial':256,
    'samples_per_mode_per_clock_protocol':24576,'mode_order':'rotates by trial; serial runs; no concurrent build/test/other benchmark jobs',
    'note':'Small result-aggregation work ran during the first APP process; all samples including that process are retained. No OS isolation, thread affinity or realtime priority was requested. Existing GUI application state was left untouched.',
    'isolated_input':'same 4096-sample .001*sin(.017*i) fixture and same continuous control equations as original; warmup increased from original34 to256 callbacks',
    'app_input':'matched deterministic noise fixture for both builds; controls fixed or legal-range deterministic sweeps outside timing',
    'clock_order':'steady_clock wall start; CLOCK_THREAD_CPUTIME_ID start; audio call with RT flag; CPU end; wall end',
    'cpu_semantics_source':'https://pubs.opengroup.org/onlinepubs/000095399/functions/clock_getres.html',
    'clock_resolution_ns':42,'clock_overhead_subtracted':False,
    'quantile':'sorted element floor(N*0.99), matching original; no trimmed samples',
    'measurement_totals':{'isolated_original_wall':147456,'isolated_paired_wall_cpu':147456,'APP_paired_wall_cpu':147456}},
 'baseline':json.loads((root/'baseline/provenance.json').read_text()),
 'baseline_verification':json.loads((root/'baseline/source-and-product-verification.json').read_text()),
 'isolated':isolated,'app':app,'app_wall_overrun_events':overruns,'calibration':cal,
 'rt_audit':{'isolated':(root/'isolated/run.stderr').read_text(),'app':'All72 runs returned0 and measured_rt_calls=0; positive allocator/free/mutex control in each process.',
   'warmup_scope':'Full plugin excludes explicitly warmed pre-existing scratch allocations, isolated stage audits from warmup onward.'},
 'source_verification':verification,
 'limitations':['Original27.097583ms event cannot be retrospectively assigned to a precise interruption mechanism.',
   'Pre-EQ original accepted binaries were absent; source commit52e432 was rebuilt with matching vendor revisions and matching headers.',
   'Full APP comparison is unloaded NAM/IR fallback with audible effects off, although disabled delay engine still advances. It is not a loaded Rectifier/NAM session.',
   'Normal CLI threads/offline rendering, not real CoreAudio/DAW realtime scheduling; no claim of portable deadline guarantees.',
   'Current-build wall overruns occurred while the rebuilt baseline had none in this finite sample; this does not establish equal tail-event probabilities.',
   'Wall-minus-CPU includes clock-boundary overhead and off-CPU time; identifies an execution-time gap, not the exact scheduler/kernel/hypervisor cause.'],
 'proposed_fix':'No DSP fix justified by these measurements. A future benchmark-reporting change could retain paired thread-CPU and wall data plus raw sample indices; leave original findings and thresholds unchanged.',
 'raw_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(root/'diagnosis.json').write_text(json.dumps(result,indent=2)+'\n')

def triple(d,maxkey='max'):
    return f"{d['p50']:.3f} / {d['p99']:.3f} / {d.get(maxkey,d.get('maximum')):.3f}"

text='''# Post-Amp EQ timing-outlier investigation

Diagnosis: **no reproducible EQ-specific CPU execution-time failure was found**.
Rare wall-clock spikes were reproduced. In the four full-plugin intervals that
exceeded the deadline, only 0.726–1.115 ms was charged to the benchmark thread;
the wall-minus-thread-CPU gap was 24.863–32.516 ms. This supports off-CPU /
benchmark-timing interruptions rather than tens of milliseconds of EQ work.
The original event has no paired CPU trace, so its precise cause remains unknown.

No DSP, UI, accepted benchmark, preset, branch, commit or acceptance threshold was
changed. All investigation files are under this temporary directory. The original
CPU CSV and summary hashes, 40 frozen production/evidence files, HEAD and vendor
state were verified unchanged.

## Original measurement boundary

The 27.097583 ms maximum was **isolated EQ**, not the complete plugin. Original
`eq-cpu.cpp` lines 85–90 start `steady_clock` after generating/publishing controls,
set the RT audit flag, execute `PostAmpEQProcessor::processBlock`, clear the flag,
and stop the clock. It includes target adoption, coefficient calculation and
sample processing, audit-flag stores and minimal clock/call overhead. It excludes
UI/control generation, setControls publication, vector bookkeeping/checksum,
sorting/printing, NAM, tone stack, cabinet, gate, tuner, pedals, delay and iPlug2.
There was no actual audio-device callback: the 23.219954648526 ms deadline was
calculated as 4096 / 176400 seconds for comparison.

The original stored only sorted p50/p99/max statistics. It has no original sample
index, paired thread CPU time or scheduler trace. Therefore the original count
of individual overruns and precise interruption location cannot be reconstructed.
Its maximum remains preserved exactly.

## Repeat protocol

176.4 kHz, 4,096 frames, unchanged 23.219954648526 ms deadline. For each condition,
12 warm runs x 2,048 measured calls = **24,576 samples**, with 256 unmeasured warm
calls per run and rotating condition order. Every measured sample is retained.
The isolated test uses the original signal/control equations, with an additional
wire/copy harness control. It runs both the original wall-only timing boundary
and a second batch with paired wall/thread-CPU clocks. The full-plugin APP uses
the same paired clock order and real Release `AppProcess` objects.

No competing build, test or benchmark job ran during the measurements. A small
CSV aggregation overlapped the first APP process; that process and all its samples
remain included. The OS was not isolated, no priority/affinity changes were made,
and the existing GUI application was left untouched. These are ordinary CLI
threads, not CoreAudio realtime threads.

The accepted pre-EQ binary directory was empty. The baseline was independently
rebuilt from accepted commit `52e432585918adac8b1b41d53311aa8635c28e44` via git archive
into a temporary directory, with exactly matching vendor revisions and old
headers. The current build uses the existing verified Release objects and current
headers. The full-plugin comparison has no NAM/IR loaded; gate, tone, selected
pedal, tuner and audible delay are disabled. The unchanged delay engine still
advances with silence. This is a matched fallback-path comparison, not a loaded
guitar rig. Export/build/object provenance is retained under `baseline/`.

## Isolated EQ, paired clocks

All times below are **microseconds**, reported as **p50 / p99 / maximum**.
CPU maxima and wall maxima can occur on different samples; paired outlier data
is retained separately. Overruns compare every sample with the unchanged budget.

| Condition | Wall us: p50 / p99 / max | Thread CPU us: p50 / p99 / max | Wall / CPU overruns |
|---|---:|---:|---:|
'''
for mode in ['wire-control','bypass-tracking','neutral-tracking','settled-five-sections','continuous-sweep','continuous-sweep-enables']:
    d=isolated['wall-threadcpu / '+mode]
    text+=f"| {mode} | {triple(d['wall'])} | {triple(d['cpu'])} | {d['wall_overruns']} / {d['cpu_overruns']} |\n"
text+='''
## Isolated EQ, original wall-only boundary

CPU time was **not measured** in this batch, rather than recorded as zero.

| Condition | Wall us: p50 / p99 / max | Wall overruns |
|---|---:|---:|
'''
for mode in ['wire-control','bypass-tracking','neutral-tracking','settled-five-sections','continuous-sweep','continuous-sweep-enables']:
    d=isolated['original-wall / '+mode]
    text+=f"| {mode} | {triple(d['wall'])} | {d['wall_overruns']} |\n"
text+='''
The same class of large elapsed spike reproduced with **neutral EQ: 34.043 ms**.
The isolated continuous-sweep overrun itself did not reproduce in either batch:
49,152 measured calls, maximum 0.239208 ms in wall-only and 0.188167 ms in paired
timing. The exact original spike is not claimed explained by this absence.

## Full APP comparison, paired clocks

| Condition | Wall us: p50 / p99 / max | Thread CPU us: p50 / p99 / max | Wall / CPU overruns |
|---|---:|---:|---:|
'''
for mode in ['baseline','bypass','neutral','active','sweep','sweep_enable']:
    d=app[mode]
    text+=f"| {mode} | {triple(d['wall'])} | {triple(d['cpu'])} | {d['wall_overruns']} / {d['cpu_overruns']} |\n"
text+='''
The pre-EQ baseline had no overruns in this finite sample. Current-bypass, active
and enable-sweep wall spikes did occur; every such spike was predominantly time
not charged to the benchmark thread, as shown below. No measured CPU interval
in any condition approached the deadline; maximum full-APP CPU was 1.231708 ms.

| Mode / trial / callback | Wall us | Paired thread CPU us | Wall minus CPU us |
|---|---:|---:|---:|
'''
for d in overruns:
    text+=f"| {d['mode']} / {d['trial']} / {d['index']} | {float(d['wall_us']):.3f} | {float(d['thread_cpu_us']):.3f} | {float(d['wall_minus_thread_cpu_us']):.3f} |\n"
text+='''
The rebuilt baseline median thread CPU was 279.167 us; current EQ modes were
348.791–357.167 us. The incremental cost is about **70–78 us per 4096-frame block**
(0.30–0.34% of its budget), consistent with the independently measured isolated
EQ cost. Bypass intentionally keeps five section histories warm. Continuously
changing parameters add about 5 us versus neutral in the full APP median. This
is bounded expected processing cost, not a reproduced 27 ms execution-time path.

## Clock / realtime checks and interpretation

`CLOCK_THREAD_CPUTIME_ID` measures execution time of the calling thread, unlike
elapsed wall time: [POSIX clock specification](https://pubs.opengroup.org/onlinepubs/000095399/functions/clock_getres.html).
The measured sequence is wall-start, CPU-start, audio call, CPU-end, wall-end.
The clocks reported 42 ns CPU-clock resolution. The empty timing envelope had
0.333 us wall / 0.167 us CPU median, and 1.125 us maximum wall overhead. Nothing
was subtracted from any result. A deliberate 30 ms sleep calibration had median
32.790166 ms wall but only 0.021208 ms thread CPU, confirming that off-CPU waits
are excluded by the CPU clock.

The RT interposer's positive allocation/free/mutex controls passed. The isolated
run and all 72 APP processes had zero audited forbidden calls during measured
processing. Full-plugin first-use storage was warmed; no later calls were waived.

The isolated paired test also captured 3.910250 ms wall with 0.176541 ms CPU in
active processing. Together with the four paired full-plugin overruns, this is
direct evidence of large off-CPU / timing-boundary gaps on this system. It does
not identify the exact scheduler, kernel, hypervisor, timer-call or interruption
mechanism. Cache stalls and slow arithmetic while a thread is running are
charged as thread CPU time; they cannot alone explain these large gaps.

The original isolated result cannot be blamed on pre-existing NAM/framework
processing, because those were absent from its timer. Evidence instead favors
benchmark/system scheduling interruptions. Current-build-only wall overruns in
this limited full-APP sample do not establish that tail probabilities are equal
to the baseline, nor prove a product scheduling guarantee.

## Diagnosis and proposed action

No EQ-specific computational regression requiring a DSP fix was found. Do not
change the filters, smoothing, bypass state tracking or acceptance thresholds
on this evidence. A useful future reporting improvement is to retain paired CPU
and wall timing, raw sample indices and overrun counts. That diagnostic approach
was used here only in temporary harnesses; the accepted benchmark is untouched.

Preserve the original 27.097583 ms finding, the neutral 34.043 ms repeat and all
four full-plugin overruns. There is no claim that they cannot occur in a real
host: a wall-time interruption can still miss an audio deadline. Exact original
cause and behavior under a loaded NAM/IR and actual realtime host scheduling
remain uncertain. This investigation stops at diagnosis; no fix is implemented.

## Retained evidence

- `diagnosis.json`: machine-readable result, complete aggregates, provenance,
  limitations and hashes of every raw CSV.
- `isolated/raw.csv`, `isolated/summary.csv`, `isolated/calibration.csv` and
  `isolated/run.stderr`: all isolated observations and RT checks.
- `app/run-*.csv`, corresponding stderr, `app/per-run-summary.json` and
  `app/overruns.json`: every native callback, per-run results and every overrun.
- `baseline/`: exact-source rebuild, compile commands, matching headers/object
  hashes, retained initial cache failure and successful build logs.
- `initial-source-manifest.json` and `final-source-verification.json`: unchanged
  source, original measurement records, HEAD, branch and vendor state.

Reproduce the isolated investigation using `isolated-timing.cpp` compiled with
unchanged `PostAmpEQProcessor.cpp`, C++20/-O3/-DNDEBUG and the original dyld RT
interposer. Native APP reproduction commands and header/object provenance are
in `baseline/`; `run-app-matrix.py` retains all twelve serial rotated trials.
'''
(root/'timing-diagnosis.md').write_text(text)
print(json.dumps({'report':str(root/'timing-diagnosis.md'),'raw_csv_files':len(files),'callbacks':442368,'source_changed':verification['changed_frozen_files']},indent=2))
