#include "/Users/marte/Code/nam_holdsworth/NeuralAmpModelerPlugin/HoldsworthEngine/dsp/PostAmpEQProcessor.h"
#include "/Users/marte/Code/nam_holdsworth/NeuralAmpModelerPlugin/HoldsworthEngine/references/post-amp-eq-v1/rt-audit.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <vector>

thread_local bool inAudio = false;
std::atomic<unsigned> rtViolations{0};
using EQ = holdsworth::dsp::PostAmpEQProcessor;
using Controls = holdsworth::dsp::PostAmpEQControls;
using Clock = std::chrono::steady_clock;
constexpr double rate = 176400.;
constexpr std::size_t frames = 4096;
constexpr unsigned trials = 12, callbacks = 2048, warmCallbacks = 256;
constexpr double deadlineUs = 1.e6 * frames / rate;
constexpr std::array names{"wire-control", "bypass-tracking", "neutral-tracking",
  "settled-five-sections", "continuous-sweep", "continuous-sweep-enables"};

static std::uint64_t cpuNs()
{
  timespec t{};
  if (clock_gettime(CLOCK_THREAD_CPUTIME_ID, &t)) std::abort();
  return static_cast<std::uint64_t>(t.tv_sec) * 1000000000ULL + static_cast<std::uint64_t>(t.tv_nsec);
}
struct Timing { double wall, cpu; };
template<class Function> Timing measured(Function&& function, bool dual)
{
  const auto wallStart = Clock::now();
  const auto cpuStart = dual ? cpuNs() : 0;
  function();
  const auto cpuEnd = dual ? cpuNs() : 0;
  const auto wallEnd = Clock::now();
  return {std::chrono::duration<double, std::micro>(wallEnd - wallStart).count(),
          dual ? static_cast<double>(cpuEnd - cpuStart) / 1000. : -1.};
}
static void publish(EQ& eq, Controls& controls, unsigned tick, unsigned mode)
{
  if (mode < 4) return;
  const double fraction = static_cast<double>(tick % 997U) / 996., reverse = 1. - fraction;
  for (std::size_t band = 0; band < 3; ++band)
  {
    const double position = band % 2 == 0 ? fraction : reverse;
    controls.bands[band] = {80. * std::pow(100., position), -12. + 24. * position,
                           .35 * std::pow(4. / .35, position)};
  }
  controls.highPassHz = 20. + 180. * fraction;
  controls.lowPassHz = 3000. + 13000. * reverse;
  controls.trimDb = -24. + 30. * fraction;
  if (mode == 5)
  {
    controls.enabled = tick % 211U < 155U;
    controls.highPassEnabled = tick % 113U < 55U;
    controls.lowPassEnabled = tick % 151U < 75U;
  }
  eq.setControls(controls);
}
static void stats(FILE* file, unsigned trial, unsigned order, const char* mode,
                  const char* clocks, const std::vector<Timing>& samples)
{
  std::vector<double> wall, cpu, gap;
  wall.reserve(samples.size()); cpu.reserve(samples.size()); gap.reserve(samples.size());
  unsigned wallOver = 0, cpuOver = 0;
  for (const auto& t : samples)
  {
    wall.push_back(t.wall); cpu.push_back(t.cpu); gap.push_back(t.cpu < 0. ? -1. : t.wall - t.cpu);
    wallOver += t.wall > deadlineUs; cpuOver += t.cpu > deadlineUs;
  }
  std::sort(wall.begin(), wall.end()); std::sort(cpu.begin(), cpu.end()); std::sort(gap.begin(), gap.end());
  std::fprintf(file,"isolated,%u,%u,%s,%s,%zu,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%u,%u,%.9f\n",
    trial, order, mode, clocks, samples.size(), wall[wall.size()/2], wall[wall.size()*99/100], wall.back(),
    cpu[cpu.size()/2], cpu[cpu.size()*99/100], cpu.back(), gap[gap.size()*99/100], gap.back(), wallOver,cpuOver,deadlineUs);
  std::fflush(file);
}
int main(int argc, char** argv)
{
  if (argc != 2) return 2;
  const std::string directory = argv[1];
  FILE* summary = std::fopen((directory+"/summary.csv").c_str(),"w");
  FILE* raw = std::fopen((directory+"/raw.csv").c_str(),"w");
  FILE* calibration = std::fopen((directory+"/calibration.csv").c_str(),"w");
  if (!summary || !raw || !calibration) return 2;
  std::fprintf(summary,"scope,trial,order,mode,clocks,count,wall_p50_us,wall_p99_us,wall_max_us,cpu_p50_us,cpu_p99_us,cpu_max_us,gap_p99_us,gap_max_us,wall_overruns,cpu_overruns,deadline_us\n");
  std::fprintf(raw,"scope,trial,order,mode,clocks,callback,control_tick,wall_us,cpu_us,wall_minus_cpu_us,wall_overrun,cpu_overrun\n");
  std::fprintf(calibration,"case,index,wall_us,cpu_us,wall_minus_cpu_us\n");
  timespec resolution{};
  if (clock_getres(CLOCK_THREAD_CPUTIME_ID,&resolution)) return 2;
  std::fprintf(stderr,"CLOCK_THREAD_CPUTIME_ID resolution=%ld.%09ld; rate=176400 frames=4096 trials=%u callbacks=%u warm=%u\n",resolution.tv_sec,resolution.tv_nsec,trials,callbacks,warmCallbacks);
  for (unsigned n=0;n<5000;++n)
  {
    auto t=measured([] { asm volatile("" ::: "memory"); },true);
    std::fprintf(calibration,"empty,%u,%.6f,%.6f,%.6f\n",n,t.wall,t.cpu,t.wall-t.cpu);
  }
  for (unsigned n=0;n<5;++n)
  {
    auto t=measured([] { timespec delay{0,30000000}; while(nanosleep(&delay,&delay)) {} },true);
    std::fprintf(calibration,"sleep30ms,%u,%.6f,%.6f,%.6f\n",n,t.wall,t.cpu,t.wall-t.cpu);
  }
  // Positive RT interception control, outside every benchmark interval.
  pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
  void* (*volatile allocate)(std::size_t)=&std::malloc;
  void (*volatile release)(void*)=&std::free;
  inAudio=true; void* memory=allocate(17); pthread_mutex_lock(&mutex); pthread_mutex_unlock(&mutex); release(memory); inAudio=false;
  pthread_mutex_destroy(&mutex);
  const unsigned self=rtViolations.exchange(0);
  std::fprintf(stderr,"RT_SELFTEST intercepted=%u expected=3\n",self);
  if(self!=3) return 3;
  volatile double checksum=0.;
  // First repeat the original wall-only boundary, then add thread-CPU clocks.
  // Mode order rotates per trial; each new instance gets 256 warm callbacks.
  for (bool dual : {false,true})
    for (unsigned trial=0;trial<trials;++trial)
      for (unsigned order=0;order<names.size();++order)
      {
        const unsigned mode=(order+trial)%static_cast<unsigned>(names.size());
        EQ eq; eq.prepare(rate,frames);
        Controls controls; controls.enabled=mode>=2;
        if(mode>=3)
        {
          controls.highPassEnabled=controls.lowPassEnabled=true;
          controls.bands={{{80.,12.,4.},{1000.,-12.,.35},{8000.,12.,4.}}}; controls.trimDb=-12.;
        }
        eq.setControls(controls); eq.reset();
        std::array<double,frames> input{},output{};
        for(std::size_t i=0;i<frames;++i) input[i]=.001*std::sin(.017*static_cast<double>(i));
        auto render=[&] { inAudio=true; if(mode==0) std::memcpy(output.data(),input.data(),sizeof(input)); else eq.processBlock(input,output); inAudio=false; };
        for(unsigned tick=0;tick<warmCallbacks;++tick) { publish(eq,controls,tick,mode); render(); }
        std::vector<Timing> samples(callbacks);
        for(unsigned n=0;n<callbacks;++n)
        {
          publish(eq,controls,n+warmCallbacks,mode);
          samples[n]=measured(render,dual);
          checksum=checksum+output[n%frames];
        }
        const char* clocks=dual?"wall-threadcpu":"original-wall";
        stats(summary,trial,order,names[mode],clocks,samples);
        for(unsigned n=0;n<callbacks;++n)
        {
          const auto& t=samples[n];
          std::fprintf(raw,"isolated,%u,%u,%s,%s,%u,%u,%.6f,%.6f,%.6f,%u,%u\n",trial,order,names[mode],clocks,n,n+warmCallbacks,t.wall,t.cpu,t.cpu<0.?-1.:t.wall-t.cpu,t.wall>deadlineUs,t.cpu>deadlineUs);
        }
      }
  std::fprintf(stderr,"RT_AUDIT violations=%u checksum=%.17g\n",rtViolations.load(),static_cast<double>(checksum));
  std::fclose(summary); std::fclose(raw); std::fclose(calibration);
  return rtViolations.load()==0?0:4;
}
